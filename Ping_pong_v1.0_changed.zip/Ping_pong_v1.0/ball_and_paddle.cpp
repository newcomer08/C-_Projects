#include "ball_and_paddle.h"
#include <raylib.h>
#include <cmath>

//! Ball state
int ball_position_x = 640;
int ball_position_y = 360;
int ball_radius = 10;
int ball_speed = 450;
float angle = 0;
float vx = 0;
float vy = 0;

//! Paddle state
int paddle_width = 30;
int paddle_height = 150;
int paddle_speed = 400;
int left_paddle_y = 285;
int right_paddle_y = 285;

//! Scores
int left_score = 0;
int right_score = 0;

void RestartBall() {
    ball_position_x = 640;
    ball_position_y = 360;
    ball_speed = 450;
    // Pick an angle that avoids nearly vertical/horizontal travel.
    angle = GetRandomValue(20, 70) + GetRandomValue(0, 3) * 90;
    vx = cosf(angle * DEG2RAD);
    vy = sinf(angle * DEG2RAD);
}
