#include <raylib.h>
#include <cmath>
#include "ball_and_paddle.h"

int main() {
    InitWindow(1280, 720, "Ping_pong");
    SetTargetFPS(120);

    bool running = true;
    while (running && !WindowShouldClose()) {
        // Wait for SPACE to start.
        bool started = false;
        while (!WindowShouldClose() && !started) {
            if (IsKeyPressed(KEY_SPACE)) {
                started = true;
                left_score = 0;
                right_score = 0;
                RestartBall();
            }
            BeginDrawing();
            ClearBackground(DARKGREEN);
            DrawText("Press SPACE to start the game", 360, 340, 40, BLACK);
            EndDrawing();
        }

        //! Game Loop
        while (!WindowShouldClose()) {
            float dt = GetFrameTime();

            //? Input
            if (IsKeyDown(KEY_W)) left_paddle_y -= paddle_speed * dt;
            if (IsKeyDown(KEY_S)) left_paddle_y += paddle_speed * dt;
            if (IsKeyDown(KEY_UP)) right_paddle_y -= paddle_speed * dt;
            if (IsKeyDown(KEY_DOWN)) right_paddle_y += paddle_speed * dt;

            // Clamp paddles inside the screen
            if (left_paddle_y < 0) left_paddle_y = 0;
            if (left_paddle_y > 720 - paddle_height) left_paddle_y = 720 - paddle_height;
            if (right_paddle_y < 0) right_paddle_y = 0;
            if (right_paddle_y > 720 - paddle_height) right_paddle_y = 720 - paddle_height;

            //? Update ball position
            ball_position_x += vx * ball_speed * dt;
            ball_position_y += vy * ball_speed * dt;

            //? Collision with top/bottom walls
            if (ball_position_y - ball_radius < 0) {
                ball_position_y = ball_radius;
                vy = -vy;
            }
            if (ball_position_y + ball_radius > 720) {
                ball_position_y = 720 - ball_radius;
                vy = -vy;
            }

            //? Collision detection with paddles
            bool left_paddle_collision = CheckCollisionCircleRec(
                Vector2{ (float)ball_position_x, (float)ball_position_y }, ball_radius,
                Rectangle{ 10, (float)left_paddle_y, (float)paddle_width, (float)paddle_height });
            bool right_paddle_collision = CheckCollisionCircleRec(
                Vector2{ (float)ball_position_x, (float)ball_position_y }, ball_radius,
                Rectangle{ 1280 - 10 - (float)paddle_width, (float)right_paddle_y, (float)paddle_width, (float)paddle_height });

            if (left_paddle_collision && vx < 0) {
                vx = -vx;
                ball_position_x = 10 + paddle_width + ball_radius;
            }
            if (right_paddle_collision && vx > 0) {
                vx = -vx;
                ball_position_x = 1280 - 10 - paddle_width - ball_radius;
            }

            //? Scoring (ball left/right of screen)
            if (ball_position_x + ball_radius < 0) {
                right_score++;
                RestartBall();
            }
            if (ball_position_x - ball_radius > 1280) {
                left_score++;
                RestartBall();
            }

            //? Draw
            BeginDrawing();
            ClearBackground(DARKGREEN);
            DrawText(TextFormat("Left Player Score: %i", left_score), 20, 20, 30, WHITE);
            DrawText(TextFormat("Right Player Score: %i", right_score), 930, 20, 30, WHITE);
            DrawRectangle(10, left_paddle_y, paddle_width, paddle_height, WHITE);
            DrawRectangle(1280 - 10 - paddle_width, right_paddle_y, paddle_width, paddle_height, WHITE);
            DrawCircle(ball_position_x, ball_position_y, ball_radius, RED);
            EndDrawing();

            //? End the game when a player reaches 5 points
            if (left_score >= 5 || right_score >= 5) break;
        }

        //! Game Over: ask to restart or quit
        bool decided = false;
        while (!WindowShouldClose() && !decided) {
            if (IsKeyPressed(KEY_SPACE)) {
                decided = true;          // restart
            }
            if (IsKeyPressed(KEY_Q) || IsKeyPressed(KEY_ESCAPE)) {
                decided = true;
                running = false;         // quit
            }
            BeginDrawing();
            ClearBackground(DARKGREEN);
            if (left_score >= 5) DrawText("Left Player wins!", 420, 260, 50, WHITE);
            else DrawText("Right Player wins!", 420, 260, 50, WHITE);
            DrawText(TextFormat("Final score: %i - %i", left_score, right_score), 460, 330, 30, WHITE);
            DrawText("Press SPACE to restart or Q/ESC to quit", 330, 400, 30, WHITE);
            EndDrawing();
        }
    }

    CloseWindow();
    return 0;
}
