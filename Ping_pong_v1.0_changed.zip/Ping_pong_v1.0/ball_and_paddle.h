#pragma once

//! Ball state
extern int ball_position_x;
extern int ball_position_y;
extern int ball_radius;
extern int ball_speed;
extern float angle;
extern float vx;
extern float vy;

//! Paddle state
extern int paddle_width;
extern int paddle_height;
extern int paddle_speed;
extern int left_paddle_y;
extern int right_paddle_y;

//! Scores
extern int left_score;
extern int right_score;

// Reset the ball to the center with a new random direction.
void RestartBall();
