# Ping Pong v1.0 (raylib)

A two-player ping pong game built with [raylib](https://www.raylib.com/).
Left player: **W / S**. Right player: **UP / DOWN**. First to 5 points wins.

## Requirements

- A C++17 compiler (GCC, Clang, or MSVC)
- CMake 3.14+
- On Linux only: install the OpenGL/X11 dev packages once:
  - Debian/Ubuntu: `sudo apt install libgl1-mesa-dev libx11-dev libxrandr-dev libxi-dev libxcursor-dev libxinerama-dev libasound2-dev`
  - Fedora: `sudo dnf install mesa-libGL-devel libX11-devel libXrandr-devel libXi-devel libXcursor-devel libXinerama-devel alsa-lib-devel`

raylib itself does **not** need to be installed: CMake will use a system
raylib if it finds one, otherwise it downloads and builds raylib 5.0
automatically.

## Build and run (any OS)

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/ping_pong        # Windows: .\build\ping_pong.exe
```

On Windows with Visual Studio, open the folder in VS Code and press
**F5**, or run the "build Ping_pong" task (Ctrl+Shift+B).
